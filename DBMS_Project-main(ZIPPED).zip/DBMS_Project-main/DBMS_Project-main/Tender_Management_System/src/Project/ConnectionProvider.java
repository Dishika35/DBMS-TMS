/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author pc
 */
public class ConnectionProvider {
    private static final Logger logger = Logger.getLogger(ConnectionProvider.class.getName());

    // Method to get a connection to the database
    public static Connection getCon() throws SQLException {
        Connection con = null;
        try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tender", "root", "dishikA@2003");
        } catch (ClassNotFoundException | SQLException e) {
            // Log the exception
            logger.log(Level.SEVERE, "Failed to establish database connection", e);
        }
        return con;
    }
}
